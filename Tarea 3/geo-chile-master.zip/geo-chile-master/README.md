# geo-chile
Todas las comunas de Chile junto a su Latitud y Longitud de su punto central aproximado.
