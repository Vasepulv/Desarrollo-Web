#! /usr/bin/python3
# -*- coding: utf-8 -*-

import cgi
import cgitb
import pymysql
import re

cgitb.enable()
print("Content-type: text/html; charset=UTF-8") # <-- Esto dice al interprete que es una pagina web
print('')
print("<html><head><link href='/~vasepulv/style.css' rel='stylesheet' type='text/css'></head>")

tipo_comida=["Al Paso", "Alemana", "Árabe"
                "Argentina","Australiana","Brasileña","Café y Snacks","Carnes","Chilena","China"
                ,"Cocina de Autor","Comida Rápida","Completos","Coreana","Cubana","Española","Exótica","Francesa","Gringa"
                ,"Hamburguesa","Helados","India","Internacional","Italiana","Latinoamericana","Mediterránea","Mexicana"
                ,"Nikkei","Parrillada","Peruana","Pescados y mariscos","Picoteos","Pizzas","Pollos y Pavos","Saludable"
                ,"Sándwiches","Suiza","Japonesa","Sushi","Tapas","Thai","Vegana","Vegetariana"]

def validarRegion(region,comuna):
    isCorrect=True
    conn=pymysql.connect(
        db="cc500263_db",
        port=3306,
        user="cc500263_u",
        passwd="ntesquesus",
        host="localhost"
    )
    try:
        with conn.cursor() as cursor:
            sql="SELECT region_id FROM comuna WHERE AND nombre=(%s);"
            cursor.execute(sql,(comuna))
            result=cursor.fetchone()
            print(result)
            if (result['region_id']==region):
                isCorrect=False
    finally:
        conn.close()
        return isCorrect


def validarNombre(nombre):
    nom=nombre.upper()
    return (len(nom)>0 and len(nom)<100)

def validarCelular(celular):
    if (celular==None):
        return True
    celular2=str(celular)
    isCorrect=celular2.isnumeric()
    isCorrect=isCorrect or (celular2.index(0)=='+' and celular2.replace('+',"").isnumeric())
    return (isCorrect and len(celular2)>8 and len(celular2)<15)

def validarEmail(email):
    rex=re.compile('\w+@\w+\.com')
    rex2=re.compile('\w+@\w+\.cl')
    return ((len(re.findall(rex,email))>0 or len(re.findall(rex2,email))>0 ) and len(email)<100)

def validarTiempo(tiempo):
    rex=re.compile('\d\d\d\d-\d\d-\d\d\s\d\d:\d\d')
    rex2=re.compile('\d\d\d\d-\d-\d\d\s\d\d:\d\d')
    return rex.search(tiempo)==None or len(rex2.search(tiempo))==None

def validarTipo(tipo):
    return (tipo in tipo_comida)

def validarDescripcion(descripcion):
    if (descripcion==None):
        return True
    return len(descripcion)<500

def validarSector(sector):
    if (sector==None):
        return True
    return (len(sector)<100)

def validarRedSocial(red, url):
    isCorrect=True
    j=0
    for r in red:
        if (r==None):
            return True
        rex=re.compile('/\w+/')
        containsUrl=url[j].startswith("https://www.")
        index=url.rfind(r+".com")
        isCorrect=isCorrect and index>9 and len(re.findall(rex,url[0]))>0 and containsUrl
        j=j+1
    return isCorrect

def validarFotos(fotos):
    isCorrect=True
    for foto in fotos:
        foto2=str(foto)
        isCorrect=isCorrect and (foto2.endswith(".jpg") or foto2.endswith(".png")) 
    return True

dict=cgi.FieldStorage()

#Validar region
region=dict.getvalue('region')

#validar comuna
comuna=dict.getvalue('comuna')

#validar nombre
nombre=dict.getvalue('nombre')

#validar celular
celular=dict.getvalue('celular')

#Validar email
email=dict.getvalue('email')

#validar sector
sector=dict.getvalue('sector')

#validar hora-inicio
dia_hora_inicio=dict.getvalue('dia-hora-inicio')

#validar hora-termino
dia_hora_termino=dict.getvalue('dia-hora-termino')

#validar tipo
tipo_comida=dict.getvalue('tipo-comida')

#validar redes sociales
red_social=dict.getvalue('red-social')

#validar descripcion
descripcion_evento=dict.getvalue('descripcion-evento')

#validar fotos
fotos=dict.getvalue('foto-comida')

#validar red social
red=[]
if (len(red_social)>0):
    for i in red_social:
        red.append(dict.getvalue(i))

conn=pymysql.connect(
    db="cc500263_db",
    port=3306,
    user="cc500263_u",
    passwd="ntesquesus",
    host="localhost"
)

try:
    with conn.cursor() as cursor:
        sql="SELECT DISTINCT id FROM region where id=(%s);"
        cursor.execute(sql,region)
        result=cursor.fetchall()
finally:
    conn.close()


valido=validarRegion(region,comuna)
valido=valido and validarNombre(nombre)
valido=valido and validarCelular(celular)
valido= valido and validarEmail(email)
valido= valido and validarSector(sector)
valido= valido and validarTipo(tipo_comida)
valido=valido and validarDescripcion(descripcion_evento)
valido=valido and validarTiempo(dia_hora_inicio)
valido= valido and validarTiempo(dia_hora_termino)
valido= valido and validarRedSocial(red,red_social)
valido=valido and validarFotos(fotos)

if (valido==False):
    print("<html>")
    print("<head>")
    print("<meta char-set=utf-8>")
    print("<title>Error</title>")
    print("<body>")
    print("<h2> Hay errores en el formulario</h2>")
    if (validarRegion(region,comuna)==False):
        print("<h3>Hay errores en la Region</h3>")
    if (validarNombre(nombre)==False):
        print("<h3>Hay errores con el nombre</h3>")
    if (validarCelular(celular)==False):
        print("<h3>Hay errores con el formato del celular></h3>")
    if (validarEmail(email)==False):
        print("<h3>Hay errores con el email</h3>")
    if (validarSector(sector)==False):
        print("<h3>Hay errores con el Sector</h3>")
    if (validarTipo(tipo_comida)==False):
        print("<h3>Hay errores con el tipo</h3>")
    if(validarDescripcion(descripcion_evento)==False):
        print("<h3>Hay errores con la descripcion</h3>")
    if (validarTiempo(dia_hora_inicio)==False or validarTiempo(dia_hora_termino)==False):
        print("<h3>Hay errores con el formato del Tiempo</h3>")
    if (validarRedSocial(red,red_social)==False):
        print("<h3>Hay errores con la red-social</h3>")
    if (validarFotos(fotos)==False):
        print("<h3>Hay errores con la foto</h3>")
    print("</body></html>")
else:
    conn2=pymysql.connect(
        db="cc500263_db",
        port=3306,
        user="cc500263_u",
        passwd="ntesquesus",
        host="localhost"
    )
    try:
        with conn2.cursor() as cursor:
            sql11="SELECT id FROM comuna WHERE nombre=(%s);"
            cursor.execute(sql11,(comuna))
            result=cursor.fetchall()

            comuna_id=int(result[0][0])
            sql2="INSERT INTO evento (comuna_id, sector, nombre, email, celular, dia_hora_inicio, dia_hora_termino, descripcion, tipo) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);"
            cursor.execute(sql2,(comuna_id,sector,nombre,email,celular,dia_hora_inicio,dia_hora_termino,descripcion_evento,tipo_comida))
            result=cursor.fetchone()
            if (result==1):
                print("Se insertó un evento")
            else:
                print("Este evento ya está en el sistema, o hubo un error.")

            conn2.commit()

            sql2="SELECT id, email FROM evento WHERE  dia_hora_inicio=(%s);"
            cursor.execute(sql2,(dia_hora_inicio))
            result=cursor.fetchall()
            if (result>1):
                sql22="SELECT id FROM evento WHERE email=(%s);"
                cursor.execute(sql22,(email))
                result=cursor.fetchall()
                if (result==1):
                    for i in fotos:
                        sql3="INSERT INTO foto (ruta_archivo, nombre_archivo, evento_id) VALUES (%s, %s, %i)"
                        index=str(i).rfind("/")
                        if (index>-1):
                            cursor.execute(sql3,(i[0:index],i[index,:],int(result['id'])))
                            result2=cursor.fetchall()
                        else:
                            cursor.execute(sql3,('./',i,result['id']))

                    if (len(red_social)>0 and len(red)>0):
                        for i in red_social:
                            sql4="INSERT INTO red_social (nombre, identificador, evento_id) VALUES (%s, %s, %i);"
                            cursor.execute(sql4,(i,red[i],int(result['id'])))
                            result2=cursor.fetchall()
            #print("window.location.href='/~vasepulv/cgi-bin/index.py'")

    finally:
        conn2.close()

